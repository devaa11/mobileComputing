package com.example.autocompleteandmultiautocomplete;


import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.MultiAutoCompleteTextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    AutoCompleteTextView autoComplete;
    MultiAutoCompleteTextView multiAutoComplete;
    Button btnShow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        autoComplete = findViewById(R.id.autoComplete);
        multiAutoComplete = findViewById(R.id.multiAutoComplete);
        btnShow = findViewById(R.id.btnShow);

        // Sample suggestion lists
        String[] countries = {
                "India", "Indonesia", "Ireland", "Iceland", "Italy",
                "United States", "United Kingdom", "Ukraine", "Uganda",
                "Canada", "China", "Chile", "Czech Republic"
        };

        String[] languages = {
                "Java", "Kotlin", "Python", "C", "C++", "C#", "JavaScript",
                "Ruby", "Swift", "Go", "Dart", "PHP", "Rust"
        };

        ArrayAdapter<String> countryAdapter =
                new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, countries);
        autoComplete.setAdapter(countryAdapter);
        autoComplete.setThreshold(1);

        ArrayAdapter<String> langAdapter =
                new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, languages);
        multiAutoComplete.setAdapter(langAdapter);
        multiAutoComplete.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
        multiAutoComplete.setThreshold(1);

        autoComplete.setOnItemClickListener((parent, view, position, id) -> {
            String selected = (String) parent.getItemAtPosition(position);
            Toast.makeText(MainActivity.this, "Selected: " + selected, Toast.LENGTH_SHORT).show();
        });

        btnShow.setOnClickListener(v -> {
            String text = multiAutoComplete.getText().toString().trim();
            if (text.isEmpty()) {
                Toast.makeText(MainActivity.this, "No values entered", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Entered: " + text, Toast.LENGTH_LONG).show();
            }
        });
    }
}
