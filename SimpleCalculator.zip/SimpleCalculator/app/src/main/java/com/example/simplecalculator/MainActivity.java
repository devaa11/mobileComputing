package com.example.simplecalculator;


import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etNum1, etNum2;
    private Button btnAdd, btnSub, btnMul, btnDiv, btnClear, btnExit;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNum1 = findViewById(R.id.etNum1);
        etNum2 = findViewById(R.id.etNum2);
        btnAdd = findViewById(R.id.btnAdd);
        btnSub = findViewById(R.id.btnSub);
        btnMul = findViewById(R.id.btnMul);
        btnDiv = findViewById(R.id.btnDiv);
        btnClear = findViewById(R.id.btnClear);
        btnExit = findViewById(R.id.btnExit);
        tvResult = findViewById(R.id.tvResult);

        btnAdd.setOnClickListener(v -> calculate(Operation.ADD));
        btnSub.setOnClickListener(v -> calculate(Operation.SUBTRACT));
        btnMul.setOnClickListener(v -> calculate(Operation.MULTIPLY));
        btnDiv.setOnClickListener(v -> calculate(Operation.DIVIDE));

        btnClear.setOnClickListener(v -> {
            etNum1.setText("");
            etNum2.setText("");
            tvResult.setText("Result: ");
            etNum1.requestFocus();
        });

        btnExit.setOnClickListener(v -> finish());
    }

    private enum Operation { ADD, SUBTRACT, MULTIPLY, DIVIDE }

    private void calculate(Operation op) {
        String s1 = etNum1.getText().toString().trim();
        String s2 = etNum2.getText().toString().trim();

        if (TextUtils.isEmpty(s1) || TextUtils.isEmpty(s2)) {
            Toast.makeText(this, "Enter both numbers", Toast.LENGTH_SHORT).show();
            return;
        }

        double n1, n2;
        try {
            n1 = Double.parseDouble(s1);
            n2 = Double.parseDouble(s2);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show();
            return;
        }

        double result;
        switch (op) {
            case ADD:
                result = n1 + n2;
                break;
            case SUBTRACT:
                result = n1 - n2;
                break;
            case MULTIPLY:
                result = n1 * n2;
                break;
            case DIVIDE:
                if (n2 == 0) {
                    Toast.makeText(this, "Cannot divide by zero", Toast.LENGTH_SHORT).show();
                    return;
                }
                result = n1 / n2;
                break;
            default:
                return;
        }

        if (result == (long) result) {
            tvResult.setText("Result: " + String.valueOf((long) result));
        } else {
            tvResult.setText("Result: " + String.valueOf(result));
        }
    }
}
