package com.example.activitylifecycle;


import android.os.Bundle;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "LifecycleDemo";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        notify("onCreate");
    }

    @Override
    protected void onStart() {
        super.onStart();
        notify("onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        notify("onResume");
    }

    @Override
    protected void onPause() {
        notify("onPause");
        super.onPause();
    }

    @Override
    protected void onStop() {
        notify("onStop");
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        notify("onDestroy");
        super.onDestroy();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        notify("onRestart");
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        // example saved state
        outState.putString("example_key", "example_value");
        notify("onSaveInstanceState");
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        // example restore
        String example = savedInstanceState.getString("example_key", "none");
        notify("onRestoreInstanceState: restored=" + example);
    }

    private void notify(String methodName) {
        String activityName = this.getClass().getSimpleName();
        String message = methodName + " -> " + activityName;
        // Use Toast to display lifecycle callbacks during demo
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        // Optionally you can also log to Logcat:
        // Log.d(TAG, message);
    }
}
