package com.example.sqlliteconnection;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText etName, etEmail;
    Button btnInsert, btnShow;
    TextView tvData;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        btnInsert = findViewById(R.id.btnInsert);
        btnShow = findViewById(R.id.btnShow);
        tvData = findViewById(R.id.tvData);

        dbHelper = new DBHelper(this);

        // INSERT DATA
        btnInsert.setOnClickListener(v -> {
            String name = etName.getText().toString();
            String email = etEmail.getText().toString();

            if (dbHelper.insertData(name, email)) {
                Toast.makeText(MainActivity.this, "Data Inserted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Insert Failed", Toast.LENGTH_SHORT).show();
            }
        });

        // SHOW DATA
        btnShow.setOnClickListener(v -> {
            Cursor cursor = dbHelper.getData();
            StringBuilder sb = new StringBuilder();

            while (cursor.moveToNext()) {
                sb.append("ID: ").append(cursor.getInt(0)).append("\n");
                sb.append("Name: ").append(cursor.getString(1)).append("\n");
                sb.append("Email: ").append(cursor.getString(2)).append("\n\n");
            }

            tvData.setText(sb.toString());
        });
    }
}
