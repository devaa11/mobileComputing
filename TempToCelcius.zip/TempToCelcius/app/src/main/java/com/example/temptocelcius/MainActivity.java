package com.example.temptocelcius;


import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText etCelsius, etFahrenheit;
    Button btnConvert;
    TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etCelsius = findViewById(R.id.etCelsius);
        etFahrenheit = findViewById(R.id.etFahrenheit);
        btnConvert = findViewById(R.id.btnConvert);
        tvResult = findViewById(R.id.tvResult);

        btnConvert.setOnClickListener(v -> convertTemperature());
    }

    private void convertTemperature() {
        String c = etCelsius.getText().toString().trim();
        String f = etFahrenheit.getText().toString().trim();

        // Convert Celsius to Fahrenheit
        if (!TextUtils.isEmpty(c) && TextUtils.isEmpty(f)) {
            double celsius = Double.parseDouble(c);
            double fahrenheit = (celsius * 9 / 5) + 32;
            tvResult.setText("Result: " + fahrenheit + " °F");
        }

        // Convert Fahrenheit to Celsius
        else if (TextUtils.isEmpty(c) && !TextUtils.isEmpty(f)) {
            double fahren = Double.parseDouble(f);
            double celsius = (fahren - 32) * 5 / 9;
            tvResult.setText("Result: " + celsius + " °C");
        }

        // If both fields are filled or empty
        else {
            Toast.makeText(this, "Enter either Celsius OR Fahrenheit", Toast.LENGTH_SHORT).show();
        }
    }
}
